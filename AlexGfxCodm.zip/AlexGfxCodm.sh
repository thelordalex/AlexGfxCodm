#!/system/bin/sh
# Temperature Reduction Script
# Created by AlexGfxCodm
depis=$(settings get global device_name)
sleep 1
echo ""
echo "
░█████╗░██╗░░░░░███████╗██╗░░██╗
██╔══██╗██║░░░░░██╔════╝╚██╗██╔╝
███████║██║░░░░░█████╗░░░╚███╔╝░
██╔══██║██║░░░░░██╔══╝░░░██╔██╗░
██║░░██║███████╗███████╗██╔╝╚██╗
╚═╝░░╚═╝╚══════╝╚══════╝╚═╝░░╚═╝

████████╗░██╗░░░░░░░██╗███████╗░█████╗░██╗░░██╗░██████╗
╚══██╔══╝░██║░░██╗░░██║██╔════╝██╔══██╗██║░██╔╝██╔════╝
░░░██║░░░░╚██╗████╗██╔╝█████╗░░███████║█████═╝░╚█████╗░
░░░██║░░░░░████╔═████║░██╔══╝░░██╔══██║██╔═██╗░░╚═══██╗
░░░██║░░░░░╚██╔╝░╚██╔╝░███████╗██║░░██║██║░╚██╗██████╔╝
░░░╚═╝░░░░░░╚═╝░░░╚═╝░░╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝╚═════╝░

░░███╗░░██████╗░░█████╗░███████╗██████╗░░██████╗
░████║░░╚════██╗██╔══██╗██╔════╝██╔══██╗██╔════╝
██╔██║░░░░███╔═╝██║░░██║█████╗░░██████╔╝╚█████╗░
╚═╝██║░░██╔══╝░░██║░░██║██╔══╝░░██╔═══╝░░╚═══██╗
███████╗███████╗╚█████╔╝██║░░░░░██║░░░░░██████╔╝
╚══════╝╚══════╝░╚════╝░╚═╝░░░░░╚═╝░░░░░╚═════╝░"
echo
echo "[ Version 1.0 AlexGfxCodm ]"
sleep 2
echo ""
echo "• Developer  : thelordalex"
echo ""
echo " [ 𝐒𝐮𝐩𝐩𝐨𝐫𝐭 𝐌𝐞 ]"
echo "-> Instagram : @ussefayman_ "
sleep 2
echo ""
echo "[ 𝐋𝐎𝐆 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ] 
 -> Starting Optimization for Device [ $depis ]"
echo ""
sleep 2
echo "[ * ] Activating Thermal Configuration.."
sleep 2
echo
echo "[ * ] Activating Performance Profile.."
sleep 3
echo
echo "[ * ] Activating HWUI Configuration.."
sleep 2
echo
echo "[ * ] Disabling Overlays.."
sleep 3
echo
echo "[ * ] Activating Surface Flinger Configuration.."
sleep 2
echo
echo "[ * ] Activating Rendering Script.."
sleep 3
echo
echo "[ * ] Killing Logger.."
sleep 1
echo
echo "[ * ] Activating Other Configurations.."
sleep 4
echo
prop=(
# Thermal Configuration
"debug.thermal.core_control_enabled 0"
"debug.thermal_zone.cpu_hotplug_control 2"
"debug.thermal_zone.cpu_threshold_temp 80"
"debug.thermal_zone.gpu_hotplug_control 2"
"debug.thermal_zone.gpu_threshold_temp 80"
# Performance Profile
"debug.performance.cap uncapped"
"debug.performance.tuning 1"
"debug.performance.profile 1"
"debug.app.performance_restricted false"
# HWUI Configuration
"debug.hwui.use_gpu_pixel_buffers 1"
"debug.hwui.force_gpu_for_2d true"
"debug.hwui.force_gpu_for_3d true"
# Disable Overlays
"debug.sf.showfps 0"
"debug.sf.showcpu 0"
"debug.sf.showbackground 0"
"debug.sf.shoupdates 0"
# Surface Flinger Configuration
"debug.sf.set_idle_timer_ms 20"
"debug.sf.disable_backpressure 1"
"debug.sf.hw 1"
"debug.sf.latch_unsignaled 1"
"debug.sf.enable_hwc_vds 1"
"debug.sf.early_app_phase_offset_ns 500000"
"debug.sf.early_gl_app_phase_offset_ns 15000000"
"debug.sf.early_gl_phase_offset_ns 3000000"
"debug.sf.early_phase_offset_ns 500000"
"debug.sf.high_fps_early_gl_phase_offset_ns 650000"
"debug.sf.high_fps_early_phase_offset_ns 6100000"
"debug.sf.high_fps_late_app_phase_offset_ns 100000"
"debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000"
# Rendering Script
"debug.renderthread.reduceopstasksplitting 1"
"debug.composition.type gpu"
"debug.rs.default-CPU-driver 1"
"debug.rs.default-GPU-driver 0"
"debug.egl.buffcount 4"
"debug.egl.force_msaa 1"
"debug.egl.hw 1"
"debug.egl.swapinterval 1"
# Kill Logger
"log.tag.ALL -"
"log.tag.APM_AudioPolicyManager -"
"log.tag.stats_log -"
"log.tag.GAv4 -"
"log.tag.FA -"
"log.tag.FA-SVC -"
"log.tag.SQLiteLog -"
"log.tag.SQLiteStatements -"
"log.tag.MParticle -"
"debug.mdpcomp.logs -"
# Other Configurations
"debug.gralloc.gfx_ubwc_disable 0"
"debug.javafx.animation.framerate 120"
"debug.systemuicompilerfilter speed"
"debug.gpuprio 7"
"debug.ioprio 7"
"debug.multicore.processing 1"
)
success_count=0
failure_count=0

for command in "${prop[@]}"; do
    if setprop $command >/dev/null 2>&1; then
        success_count=$((success_count + 1))
    else
        failure_count=$((failure_count + 1))
        failed_commands+=("$command")
    fi
done
echo "[ ! ] Total Applied         : $success_count"
echo "____________________"
sleep 1
echo 
echo "[ ! ] Total Not Applied     : $failure_count"
echo "____________________"
echo ""
sleep 2
echo "[ Warning ] Do not restart your device!"
sleep 2
echo ""
echo "Process complete. Exiting with code 0."
sleep 1
echo ""
echo "All done"
echo
sleep 0.5
echo "Cleaned All ->"
cmd notification post -S bigtext -t '𝐀𝐋𝐞𝐱 𖤩 Mode Status' 'tag' "𝐀𝐋𝐞𝐱 𖤩 Mode Activated 🚀" > /dev/null 2>&1 &
nohup sh /sdcard/Mode/.Clear/run.sh > /dev/null 2>&1